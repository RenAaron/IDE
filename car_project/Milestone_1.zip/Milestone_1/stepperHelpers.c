#include "stepperHelpers.h"
#include "uart.h"

double center_duty = 8;
double left_duty = 13;
double right_duty = 3;

int buffer = 10;

void initStepper(){
    TIMA1_PWM_init(4, 2510, 255, center_duty);    //init PWM for PA4, load, prescaler, duty cycle
}

double findCenterPWM(int index){

    return (((1 - ((index) / 100.0))) * (left_duty - right_duty)) + right_duty;
}

void turnTowardIndex(int index){
    TIMA1_PWM_DutyCycle(4, findCenterPWM(index));    // set PA4 duty cycle to value that will center it
    //TIMA1_PWM_DutyCycle(4, (index));    // set PA4 duty cycle to value that will center it
}