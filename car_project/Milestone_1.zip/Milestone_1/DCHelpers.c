#include "DCHelpers.h"

void setLeftEnable(){
    if (!(GPIOB->GPRCM.PWREN & GPIO_PWREN_ENABLE_MASK)) { // if GPIOB is not powered on 
        GPIOB->GPRCM.RSTCTL |= (GPIO_RSTCTL_KEY_UNLOCK_W | GPIO_RSTCTL_RESETASSERT_ASSERT); // reset GPIOB
        GPIOB->GPRCM.PWREN |= (GPIO_PWREN_KEY_UNLOCK_W | GPIO_PWREN_ENABLE_ENABLE); // power on GPIOB
		}
    
    IOMUX->SECCFG.PINCM[IOMUX_PINCM45] |= (0x80 | 0x01); // Select PB19 for use as port I/O
		IOMUX->SECCFG.PINCM[IOMUX_PINCM45] |= IOMUX_PINCM_INENA_ENABLE; // Set PB19 to input mode
		IOMUX->SECCFG.PINCM[IOMUX_PINCM45] |= IOMUX_PINCM_DRV_DRVVAL1; // set drive to 1
		IOMUX->SECCFG.PINCM[IOMUX_PINCM45] |= IOMUX_PINCM_PC_CONNECTED; // set PC connected PB19
    
		GPIOB->DOESET31_0 |= GPIO_DOESET31_0_DIO19_SET;
    
    GPIOB->DOUTSET31_0 = GPIO_DOUTSET31_0_DIO19_SET; 
}

void setRightEnable(){
    
    if (!(GPIOA->GPRCM.PWREN & GPIO_PWREN_ENABLE_MASK)) { // if GPIOA is not powered on 
        GPIOA->GPRCM.RSTCTL |= (GPIO_RSTCTL_KEY_UNLOCK_W | GPIO_RSTCTL_RESETASSERT_ASSERT); // reset GPIOA 
        GPIOA->GPRCM.PWREN |= (GPIO_PWREN_KEY_UNLOCK_W | GPIO_PWREN_ENABLE_ENABLE); // power on GPIOA
    }
    
    IOMUX->SECCFG.PINCM[IOMUX_PINCM47] |= (0x80 | 0x01); // Select PA22 for use as port I/O
		IOMUX->SECCFG.PINCM[IOMUX_PINCM47] |= IOMUX_PINCM_INENA_ENABLE; // Set PA22 to input mode
		IOMUX->SECCFG.PINCM[IOMUX_PINCM47] |= IOMUX_PINCM_DRV_DRVVAL1; // set drive to 1
		IOMUX->SECCFG.PINCM[IOMUX_PINCM47] |= IOMUX_PINCM_PC_CONNECTED; // set PC connected PA22
    
		GPIOA->DOESET31_0 |= GPIO_DOESET31_0_DIO22_SET;
    
    GPIOA->DOUTSET31_0 = GPIO_DOUTSET31_0_DIO22_SET; 
    
}

void turnRight(int turnSpeed){
	//(pin, freq)
		//initialize left wheel for x frequency
  TIMA0_PWM_DutyCycle(12, 0); // right reverse 
  TIMA0_PWM_DutyCycle(8, turnSpeed);    // right forward
    
  //initialize right wheel for x frequency
  TIMA0_PWM_DutyCycle(13, 0); // left reverse 
  TIMA0_PWM_DutyCycle(17, turnSpeed + 10);    // left forward
}

void turnLeft(int turnSpeed){
	// (pin, freq)
		//initialize left wheel for x frequency
  TIMA0_PWM_DutyCycle(12, 0); // right reverse 
  TIMA0_PWM_DutyCycle(8, turnSpeed + 10);    // right forward
    
  //initialize right wheel for x frequency
  TIMA0_PWM_DutyCycle(13, 0); // left reverse 
  TIMA0_PWM_DutyCycle(17, turnSpeed);    // left forward
}

void initMotorTimers(){
	//initialize right wheel for x frequency
  TIMA0_PWM_init(12, 3200, 0, 0); // right reverse 
  TIMA0_PWM_init(8, 3200, 0, 0);    // right forward
    
  //initialize left wheel for x frequency
  TIMA0_PWM_init(13, 3200, 0, 0); // left reverse 
  TIMA0_PWM_init(17, 3200, 0, 0);    // left forward
}


void driveForward(int speed){
	
	//initialize left wheel for x frequency
  TIMA0_PWM_DutyCycle(12, 0); // right reverse 
  TIMA0_PWM_DutyCycle(8, speed);    // right forward
    
  //initialize right wheel for x frequency
  TIMA0_PWM_DutyCycle(13, 0); // left reverse 
  TIMA0_PWM_DutyCycle(17, speed);    // left forward
}