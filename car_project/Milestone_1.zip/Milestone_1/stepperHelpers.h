#include "timers.h"

extern double center_duty;
extern double left_duty;
extern double right_duty;

void initStepper();

double findCenterPWM(int centerIndex);

void turnTowardIndex(int index);

void turnRight(int turnSpeed);
void turnLeft(int turnSpeed);