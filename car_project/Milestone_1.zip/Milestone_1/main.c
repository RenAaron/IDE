#include "DCHelpers.h"
#include "stepperHelpers.h"
#include "uart.h"
#include "camera.h"
#include "i2c.h"
#include "oled.h"
#include "leds.h"
#include "switches.h"
#include <stdlib.h>


unsigned char OLED_TEXT_ARR[1024];
unsigned char OLED_GRAPH_ARR[1024];

int maxCameraData;

/* DUTY CYCLE VARIABLES */
int index_sum;
int index_length;
int turn_index;

/* PID CONTROL */
//position variables
double PositionOld = 64.0;	//start at center position so that car starts centered
double PositionActual = 0.0;
double PositionDesired = 64.0;	//center index value
double Position = 0.0;

//error variables
double Err = 0.0;
double ErrOld1 = 0.0;
double ErrOld2 = 0.0;

//constant values for PID - should all be between 0 and 1
double Kp = 0.65;
double Ki = 0.1;	//0.1 ??
double Kd = 0.0;	//0.00001 ??

void TIMG6_IRQHandler(){
	if(GPIOA->DOUT31_0 & GPIO_DOUTSET31_0_DIO12_SET){         //if clock is high 
		GPIOA->DOUTCLR31_0 = GPIO_DOUTCLR31_0_DIO12_CLR;     //clear clock 
	}
					
	GPIOA->DOUTSET31_0 = GPIO_DOUTSET31_0_DIO28_SET; //set SI high 
	GPIOA->DOUTSET31_0 = GPIO_DOUTSET31_0_DIO12_SET; //set CLK high  
					 
	GPIOA->DOUTCLR31_0 = GPIO_DOUTSET31_0_DIO28_SET; //set SI low 
	GPIOA->DOUTCLR31_0 = GPIO_DOUTSET31_0_DIO12_SET; //set CLK low 
	
	TIMG0->COUNTERREGS.CTRCTL |= GPTIMER_CTRCTL_EN_ENABLED; //enable TIMG0
}


void TIMG0_IRQHandler(){
	GPIOA->DOUTTGL31_0 |= GPIO_DOUTTGL31_0_DIO12_TOGGLE;    //set clock to go high if it's low and low if it's high
	
	if(GPIOA->DOUT31_0 & GPIO_DOUTSET31_0_DIO12_SET){       //if clk high 
		if(pixelCounter <= 127){

			cameraData[pixelCounter] = ADC0_getVal();
			
			pixelCounter++;
		} else{
			pixelCounter = 0;                 //reset index 
			cameraData_complete = 1;     //set done flag
			TIMG0->COUNTERREGS.CTRCTL &= ~GPTIMER_CTRCTL_EN_ENABLED; //STOP TIMG6 
		}
	}
}

void wait(){ // sort of an arbitrary wait 
	for(int i = 0; i < 1000000; i++){
	}
}

int detectStopTape(){
	
	// pixels      0 - 20: left track
	// pixels     21 - 30: left tape start
	// pixels     31 - 50: left tape end
	// pixels     51 - 70: center track
	// pixels     71 - 80: right tape start
	// pixels    81 - 100: right tape end
	// pixels   101 - 127: right track 
	
	// 0 => starting,               looking for left track 
	// 1 => got track,              looking for left tape start
	// 2 => got left tape start,    looking for left tape end
	// 3 => got left tape end,      looking for center track 
	// 4 => got track on center,    looking for right tape start
	// 5 => got right tape start,   looking for right tape end
	// 6 => got right tape end,     looking for right track
	// 7 => got track on right,     STOP CAR, return 1
	
	int min_track_threshold = 1000; // 1500 w/ 800 SI
	int max_tape_threshold  = 550; // 1000 w/ 800 SI 
	
	int stage = 0;
		
	int max_left_track = 20;
	int max_left_tape_start = 30;
	int max_left_tape_end = 50;
	int max_center_track = 70;
	int max_right_tape_start = 80;
	int max_right_tape_end = 100;
	int max_right_track = 127;
	
	int buffer = 30;
	
	for(int i = 0; i < 127; i++){ // loop through all camera data
		
		int pixel_brightness = Camera_getData()[i];
		
		switch(stage){
			
			case 0:
				// 0 => starting, looking for left track 
				// UART0_put((uint8_t *)"Got stage 0\r\n");
				LED2_set(CLEAR);
				if(i > 0 && i <= max_left_track){
					if(pixel_brightness > min_track_threshold){
						stage++;
					}
				}
				break;
			
			case 1:
				// 1 => got track, looking for left tape start
				if(i > max_left_track  - buffer && i <= max_left_tape_start + buffer ){
					if(pixel_brightness < max_tape_threshold){
						stage++;
					}
				}
				break;
			
			case 2:
				// 2 => got left tape start, looking for left tape end
				if(i > max_left_tape_start - buffer && i <= max_left_tape_end + buffer ){
					if(pixel_brightness > min_track_threshold){
						stage++;
					}
				}
				break;
			
			case 3:
				// 3 => got left tape end, looking for center track 
				if(i > max_left_tape_end - buffer && i <= max_center_track + buffer ){
					if(pixel_brightness > min_track_threshold){
						stage++;
					}
				}
				break;
			
			case 4:
				// 4 => got track on center, looking for right tape start
				if(i > max_center_track - buffer && i <= max_right_tape_start + buffer ){
					if(pixel_brightness < max_tape_threshold){
						stage++;
					}
				}
				break;
			
			case 5:
				// 5 => got right tape start, looking for right tape end;
				if(i > max_right_tape_start - buffer && i <= max_right_tape_end + buffer ){
					if(pixel_brightness > min_track_threshold){
						stage++;
					}
				}
				break;
			
			case 6:
				// 6 => got right tape end, looking for right track
				if(i > max_right_tape_end - buffer && i <= max_right_track){
					if(pixel_brightness > min_track_threshold){
						stage++;
					}
				}
				break;
			
			case 7:
				LED2_set(WHITE); // TAPE STOP DETECTED
			  while(1){}
				break;
			
			default:
				break;
		}
	}
	
	return 0;
}

void adjustSpeed(int turnIndex, int min, int mult){
	int delta = abs(turnIndex - 64);
	int newSpeed = (1 - (delta/64.0))*mult + min;
	
	driveForward(newSpeed);
}

void adjustTurnSpeed(int turnIndex, int min, int mult){
    int delta = turnIndex - 64;    // negative = left, positive = right
    int turnSpeed = (1 - (abs(delta)/64.0))*mult + min;
    
    if(delta > 0){    //positive = right turn
        turnRight(turnSpeed);
    }else{    // negative = left turn
        turnLeft(turnSpeed);
    }
}

void printCameraData(){
	while(1){
		while(Camera_isDataReady()){
      UART0_put((uint8_t *)"-1\r\n");
      for(int i = 0; i < 128; i++){
				UART0_printDec(Camera_getData()[i]);
        UART0_put((uint8_t *)"\r\n");
      }
      UART0_put((uint8_t *)"-2\r\n");
   }
  }
}

void modeStandard(int min, int mult){
	
	while(1){
		/* read camera data */
		while(Camera_isDataReady()){

			index_sum = 0;
			index_length = 0;
			
			
			for(int i = 0; i < 127; i++){        // loop through all camera data
				if(Camera_getData()[i] >= 2000){
					index_sum += i;
					index_length ++;
				}//get value in array
			}
			
			turn_index = index_sum/index_length;
			
			/* PID control */
			PositionActual = turn_index; //index position from camera
			Err = PositionActual - PositionDesired;	//negative error = too far left, positive error = too far right (-64, +64)
			ErrOld2 = Kp * (Err - ErrOld1);
			Position = PositionOld +
				Kp * (Err - ErrOld1) +		// proportional control
				Ki * (Err - ErrOld1)/2.0 +	// integral control
				Kd * (Err - 2.0 * ErrOld1 + ErrOld2);	// derivative control
			
			PositionOld = Position;
			ErrOld2 = ErrOld1;
			ErrOld1 = Err;
			
			// UART0_printDec(Position);
			// UART0_put((uint8_t *)"\r\n");

			/* DC motor control */
			if(turn_index != 0 && index_length < 127){	// if the turn index passes the threshold from camera center loop
				LED2_set(CLEAR);
				LED2_set(GREEN);
				// adjustSpeed(turn_index, min, mult);
				adjustTurnSpeed(turn_index, min, mult);
				turnTowardIndex(Position);
			} else if(index_length >= 120) {
				LED2_set(CLEAR);
				LED2_set(BLUE);
				adjustSpeed(turn_index, min, mult);
			}else{
				
				LED2_set(CLEAR);
				LED2_set(RED);
				driveForward(0);	//carpet stop
			}
		}
	}
}

int main(){  
	UART0_init();
	TIMG6_init(32000, 0); // init millisecond counter 
	
	LED1_init();
	LED2_init();
	
	S1_init();
	S2_init();
	
	setLeftEnable(); 
	setRightEnable();
	initMotorTimers();

	initStepper();

	ADC0_init();
	Camera_init();
	OLED_Init();

	/* reset display */
	OLED_display_on();
	OLED_display_clear();
	OLED_display_on();
	
	while(0){
		// detectStopTape();
		printCameraData();
	}
	
	int mode = 0 ;
	
	// s1 switches mode 
	// s2 selects mode 
	
	while(1){ // switching through selecting modes
		
		modeStandard(10, 30); // normal
		
		switch(mode){
			case 0:
				
				LED2_set(CLEAR); 
				LED2_set(RED); // status LED for fast
			
				if(S1_pressed()){
					mode++;
					wait(); // progress to next mode 
				} 
				
				if(S2_pressed()){
					LED1_set(ON);
					modeStandard(30, 40); // fast 
				}
				break;
			
			case 1:
				LED2_set(CLEAR); 
				LED2_set(GREEN); // status LED for normal 
			
				if(S1_pressed()){
					mode++;
					wait();
				} 
				
				if(S2_pressed()){
					LED1_set(ON);
					modeStandard(10, 35); // normal
				}
				break;
			
			case 2:
				LED2_set(CLEAR);
				LED2_set(BLUE);

			
				if(S1_pressed()){
					mode = 0;
					wait();
				} 
				
				if(S2_pressed()){
					LED1_set(ON);
					modeStandard(20, 10); // slow 
				}
				break;
				
			default:
				break;
		}
	}
	
	return 0;
    
}