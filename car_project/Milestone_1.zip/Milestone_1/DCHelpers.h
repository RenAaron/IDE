#include "timers.h"

void setLeftEnable();

void setRightEnable();

void initMotorTimers();

void driveForward(int speed);